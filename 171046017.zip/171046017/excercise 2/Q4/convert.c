float convert(float x)
{
	return (x/36);
}