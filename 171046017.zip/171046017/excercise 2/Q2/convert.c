float kilowatt(float jps)
{
    return (jps*3.6);
}