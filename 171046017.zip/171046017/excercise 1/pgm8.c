
#include <stdio.h>
int main()
{
    int a;
    float b;
    double c;
    char D;
    printf("Size of int: %ld byte\n",sizeof(a));
    printf("Size of float: %ld byte\n",sizeof(b));
    printf("Size of double: %ld byte\n",sizeof(c));
    printf("Size of char: %ld byte\n",sizeof(D));
    return 0;
}
